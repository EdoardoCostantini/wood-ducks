# Folder Structure

- data folder
	- raw
	- clean
- code
	- analysis
	- cleaning
- results

# Data collection

Students collected data from the field following a template (LINK).

# Cleaning data

The cleaning of the data can be done by using the scirpt "merge-xlsx.R". This script creates a .csv file in the data > clean subdirectory.

Instrucitnos:
- open the script "merge-xlsx.R"
- check all of the raw data are imported
- run the script

# Analysis